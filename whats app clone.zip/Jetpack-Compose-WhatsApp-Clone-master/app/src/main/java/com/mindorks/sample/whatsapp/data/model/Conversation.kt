package com.mindorks.sample.whatsapp.data.model

data class Conversation(
    val id: Int,
    val chat: String
)