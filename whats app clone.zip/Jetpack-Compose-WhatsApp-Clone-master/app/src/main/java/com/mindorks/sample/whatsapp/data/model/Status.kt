package com.mindorks.sample.whatsapp.data.model

data class Status(
    val name: String,
    val imageUrl: String,
    val time: String
)