package com.mindorks.sample.whatsapp.ui

import androidx.compose.ui.graphics.Color

val primaryWhatsAppColor = Color(0xFFBB86FC)
val purple500 = Color(0xFF6200EE)
val purple700 = Color(0xFF3700B3)
val teal200 = Color(0xFF03DAC5)