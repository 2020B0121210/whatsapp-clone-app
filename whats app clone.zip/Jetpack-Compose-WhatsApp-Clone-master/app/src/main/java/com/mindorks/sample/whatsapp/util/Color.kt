package com.mindorks.sample.whatsapp.util

import androidx.compose.ui.graphics.Color


fun colorGreen() = Color(3, 183, 144)

fun colorTopBar() = Color(33, 46, 55)

fun colorLightGreen() = Color(21, 31, 40)